package nnl.aide.material;
import java.io.*;

public class Movie implements Serializable
{
	public String title,desc,year,thumbnail,link,category,published;
}

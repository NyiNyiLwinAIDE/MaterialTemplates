package nnl.aide.material;
import android.support.v7.app.*;
import android.os.*;
import android.support.design.widget.*;
import android.view.*;
import android.support.v4.widget.*;
import android.view.View.*;
import android.widget.*;
import android.support.v4.view.*;

public class MainActivity extends ToolbarActivity
implements NavigationView.OnNavigationItemSelectedListener
{
	FloatingActionButton mFab;
    NavigationView mNavView;
	ViewPager mViewPager;
	TabLayout mTabLayout;
    DrawerLayout mDrawerLayout;
	MainFragment mMainFragment;
	WebFragment webFrag;
	@Override
	public boolean onNavigationItemSelected(MenuItem p1)
	{
		return false;
	}

	@Override
	protected int layoutId()
	{
		return R.layout.main;
	}


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		initView();
		initDrawer();
	}

	private void initView() {
		mViewPager=(ViewPager)findViewById(R.id.viewPager);
		mTabLayout=(TabLayout)findViewById(R.id.tabLayout);
		mFab=(FloatingActionButton)findViewById(R.id.fab);
		mNavView=(NavigationView)findViewById(R.id.nav_view);
		mDrawerLayout=(DrawerLayout)findViewById(R.id.drawer_layout);
        setSupportActionBar(mToolbar);
        mFab.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1)
				{
					Toast.makeText(MainActivity.this,"FAB Clicked.",0).show();
				}
			});

		HomePagerAdapter mAdapter = new HomePagerAdapter(getSupportFragmentManager());
		mMainFragment = new MainFragment("https://devofandroid.blogspot.com/feeds/posts/default?alt=json&max-results=999");
//        mMultiCityFragment = new MultiCityFragment();
		//mAdapter.addTab(mMainFragment, "主页面");
        mAdapter.addTab(mMainFragment, "Android");
		
		webFrag=new WebFragment("https://www.blogger.com/feeds/7118757755628315212/posts/default/2962366599907150944?alt=json");
		mAdapter.addTab(webFrag,"Status");
        mViewPager.setAdapter(mAdapter);
//        FabVisibilityChangedListener fabVisibilityChangedListener = new FabVisibilityChangedListener();
        mTabLayout.setupWithViewPager(mViewPager, false);

	}

	private void initDrawer() {
        if (mNavView != null) {
            mNavView.setNavigationItemSelectedListener(this);
            mNavView.inflateHeaderView(R.layout.nav_header_main);
//            ActionBarDrawerToggle toggle =
//                new ActionBarDrawerToggle(this, mDrawerLayout, getToolbar(),"open","close");
//            mDrawerLayout.addDrawerListener(toggle);
//            toggle.syncState();
        }
    }
}


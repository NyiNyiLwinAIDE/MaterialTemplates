package nnl.aide.material;

import android.os.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class BaseGetTask<T> extends AsyncTask<String,Void,T>
{
	private HttpURLConnection httpConn;
	private TaskCompletionListener listener;
	private boolean error=false;
	private String errorMsg="";
	private BaseParser<T> parser;

	public BaseGetTask(TaskCompletionListener listener,BaseParser<T> parser){
		this.listener=listener;
		this.parser=parser;
	}

	@Override
	protected T doInBackground(String[] p1)
	{
		try
		{
			URL url=new URL(p1[0]);
			httpConn = (HttpURLConnection)url.openConnection();
			httpConn.setUseCaches(false);
			httpConn.setRequestMethod("GET");
			InputStream is = httpConn.getInputStream();
			BufferedReader rd = new BufferedReader(new InputStreamReader(is));
			String line;
			StringBuffer response = new StringBuffer(); 
			while((line = rd.readLine()) != null) {
				response.append(line);
				response.append('\n');
			}
			rd.close();
			return parser.parse(response.toString());

		}
		catch (Exception e)
		{
			error=true;
			errorMsg=e.toString();
			return null;
		}
		finally{
			if(httpConn != null) {
				httpConn.disconnect(); 
			}
		}
	}

	@Override
	protected void onPostExecute(T result)
	{
		super.onPostExecute(result);
		if(listener!=null){
			if(!error){
				listener.onComplete(result);
			}else{
				listener.onError(errorMsg);
			}
		}
	}

	public static interface TaskCompletionListener<T>{
		public void onComplete(T result)
		public void onError(String msg)
	}
}

package nnl.aide.material;

import org.json.*;

public class SinglePostParser extends BaseParser<Post>
{

	@Override
	public Post parse(String str)
	{
		try{
			JSONObject jo=new JSONObject(str);
			
				jo=jo.getJSONObject("entry");
				String title=jo.getJSONObject("title").getString("$t");
				String content=jo.getJSONObject("content").getString("$t");
				String published=jo.getJSONObject("published").getString("$t");

				Post post=new Post();
				post.title=title;
				post.content=content;
				post.mini="";
				post.published=published;
				post.thumbnail="";
				
				return post;
			}catch(Exception e){
				e.printStackTrace();
				return null;
			}
	}
	
}

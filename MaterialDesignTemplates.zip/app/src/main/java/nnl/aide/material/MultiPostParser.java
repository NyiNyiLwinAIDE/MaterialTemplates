package nnl.aide.material;

import android.text.*;
import java.util.*;
import org.json.*;

public class MultiPostParser extends BaseParser<List<Post>>
{

	@Override
	public List<Post> parse(String str)
	{
		try{
			List<Post> posts=new ArrayList<>();
			JSONObject jo=new JSONObject(str);
			
			JSONArray ja=jo.getJSONObject("feed").getJSONArray("entry");
			JSONObject jo2;
			for(int i=0;i<ja.length();i++){
				jo2=ja.getJSONObject(i);
				String title=jo2.getJSONObject("title").getString("$t");
				String content=jo2.getJSONObject("content").getString("$t");
				String mini=Html.fromHtml(content).toString();
				mini=((mini.length()>=100?mini.substring(0,100):mini)+" ...").replace("\ufffc","").replaceAll("\n+","\n");
				String published=jo2.getJSONObject("published").getString("$t");
				String thumbnail="";
				if(jo2.has("media$thumbnail")){
					thumbnail=jo2.getJSONObject("media$thumbnail").getString("url").replace("/s72-c/", "/s1200/").replace("?imgmax=800", "");
				}
				Post post=new Post();
				post.title=title;
				post.content=content;
				post.mini=mini;
				post.published=published;
				post.thumbnail=thumbnail;
				posts.add(post);
			}
			return posts;

		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}

package nnl.aide.material;

import android.text.*;
import java.util.*;
import org.json.*;

public class MovieParser extends BaseParser<List<Movie>>
{

	@Override
	public List<Movie> parse(String str)
	{
		str=Html.fromHtml(str).toString();
		if(str.indexOf("<body>")>=0)
			str=str.substring(str.indexOf("<body>")+6);
		if(str.indexOf("</body>")>=0)
			str=str.substring(0,str.indexOf("</body>"));
		
			
		try{
			List<Movie> movies=new ArrayList<>();
			JSONArray ja=new JSONArray(str);
			JSONObject jo;
			for(int i=0;i<ja.length();i++){
				jo=ja.getJSONObject(i);
				String title=jo.getString("title");
				String desc=jo.getString("desc");
				String year=jo.getString("year");
				String category=jo.getString("category");
				String thumbnail=jo.getString("thumbnail");
				String link=jo.getString("link");
				String published=jo.getString("published");
				
				Movie movie=new Movie();
				movie.title=title;
				movie.desc=desc;
				movie.category=category;
				movie.year=year;
				movie.thumbnail=thumbnail;
				movie.link=link;
				movie.published=published;
				
				movies.add(movie);
				
			}
			return movies;

		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}

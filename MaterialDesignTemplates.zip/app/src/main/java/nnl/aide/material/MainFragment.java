package nnl.aide.material;
import android.os.*;
import android.support.annotation.*;
import android.support.v4.app.*;
import android.support.v4.widget.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainFragment extends Fragment {
    RecyclerView mRecyclerView;
    SwipeRefreshLayout mRefreshLayout;
	String url;
    private List<Post> posts=new ArrayList<>();
    private PostAdapter mAdapter;
    private View view;

	public MainFragment(String url){
		this.url=url;
	}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (view == null) {
            view = inflater.inflate(R.layout.content_main, container, false);
			mRecyclerView=view.findViewById(R.id.recyclerview);
			mRefreshLayout=view.findViewById(R.id.swiprefresh);
        }
        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initView();
    }

    private void initView() {
        if (mRefreshLayout != null) {
            mRefreshLayout.setColorSchemeResources(android.R.color.holo_blue_bright,
												   android.R.color.holo_green_light,
												   android.R.color.holo_orange_light,
												   android.R.color.holo_red_light);
            mRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener(){

					@Override
					public void onRefresh()
					{
						load();
					}
				});
			mRefreshLayout.postDelayed(new Runnable(){

					@Override
					public void run()
					{
						load();
					}
				}, 1000);
        }

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mAdapter = new PostAdapter();
		mRecyclerView.setAdapter(mAdapter);
    }

    private void load() {
		mRefreshLayout.setRefreshing(true);
		
		new BaseGetTask<List<Post>>(new BaseGetTask.TaskCompletionListener<List<Post>>(){

				@Override
				public void onComplete(final List<Post> posts)
				{
					mRefreshLayout.setRefreshing(false);
					if(posts!=null){
//						new Handler(Looper.getMainLooper()).post(new Runnable(){
//
//								@Override
//								public void run()
//								{
									mAdapter.setList(posts);
									MainFragment.this.posts=posts;
									//mAdapter = new PostAdapter(posts);
									//mRecyclerView.setAdapter(mAdapter);
									Toast.makeText(getActivity(),posts.size()+" posts.",0).show();
						
					}else{
						Toast.makeText(getActivity(),"post list null.",0).show();
					}
				}

				@Override
				public void onError(String msg)
				{
					mRefreshLayout.setRefreshing(false);
					Toast.makeText(getActivity(),msg,0).show();
				}
			}, new MultiPostParser()).execute(url);
		
//		new HttpGetTask2(new HttpGetTask2.TaskCompletionListener(){
//
//				@Override
//				public void onComplete(List<Post> posts)
//				{
//					mRefreshLayout.setRefreshing(false);
//					if(posts!=null){
//						mAdapter.setList(posts);
//					}
//				}
//
//				@Override
//				public void onError(String msg)
//				{
//					mRefreshLayout.setRefreshing(false);
//					Toast.makeText(getActivity(),msg,0).show();
//				}
//			},false).execute(url);
    }

    public List<Post> getPosts() {
        return posts;
    }
	
	public void filter(String str){
		mAdapter.filter(str);
	}
}



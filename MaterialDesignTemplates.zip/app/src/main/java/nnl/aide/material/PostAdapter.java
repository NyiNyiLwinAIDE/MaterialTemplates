package nnl.aide.material;

import android.content.*;
import android.support.v7.widget.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import android.text.*;
//import com.squareup.picasso.Picasso;

public class PostAdapter extends AnimRecyclerViewAdapter<RecyclerView.ViewHolder> {
    private static String TAG = PostAdapter.class.getSimpleName();

    private Context mContext;
    private List<Post> posts,filteredPosts;

    public PostAdapter() {
        this.posts = new ArrayList<>();
		this.filteredPosts=new ArrayList<>();
    }

	//If items should have different layouts
    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        mContext = parent.getContext();
        return new PostViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_layout, parent, false));
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ((PostViewHolder)holder).bind(filteredPosts.get(position));
        //showItemAnim(holder.itemView, position);
    }

    @Override
    public int getItemCount() {
        return filteredPosts.size();
    }

    public class PostViewHolder extends BaseViewHolder<Post>
	{
		TextView tvTitle,tvPublished,tvContent;
		ImageView iv;
		
		@Override
		protected void bind(Post post)
		{
			tvTitle.setText(post.title);
			tvPublished.setText(post.published);
			
			tvContent.setText(post.mini);
			
			if(post.thumbnail.length()>0){
				ImageLoader.load(mContext,post.thumbnail,iv);
			}
		}
	
        public PostViewHolder(View itemView) {
            super(itemView);
			tvTitle=itemView.findViewById(R.id.tvTitle);
			tvPublished=itemView.findViewById(R.id.tvPublished);
			tvContent=itemView.findViewById(R.id.tvContent);
			iv=itemView.findViewById(R.id.iv);
			
        }
    }
	
	public void setList(List<Post> posts){
		this.posts.clear();
		this.posts.addAll(posts);
		this.filteredPosts.clear();
		this.filteredPosts.addAll(posts);
		notifyDataSetChanged();
	}
	
	public void filter(String charText) {

		charText = charText.toLowerCase();

		filteredPosts.clear();

		if (charText.length() == 0) {

			filteredPosts.addAll(posts);
			Toast.makeText(mContext,"#"+posts.size(),0).show();

		} else {
			for (Post p : posts) 
			{
				if (p.title.toLowerCase().contains(charText)) 
				{
					filteredPosts.add(p);
				}
			}
		}
		notifyDataSetChanged();
		Toast.makeText(mContext,"#"+filteredPosts.size(),0).show();
	}
	
	public void resetFilter(){
		filteredPosts=posts;
		notifyDataSetChanged();
	}
}



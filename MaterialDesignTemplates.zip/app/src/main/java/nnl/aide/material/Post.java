package nnl.aide.material;
import java.io.*;

public class Post implements Serializable
{
	public String title, published, content,mini, thumbnail;
}

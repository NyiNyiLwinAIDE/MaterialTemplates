package nnl.aide.material;
import android.os.*;

public class TestActivity extends $Toolbar_Activity
{
	MainFragment mainFrag;
	@Override
	protected int _getMenuXmlId()
	{
		// TODO: Implement this method
		return R.menu.sample_options_menu;
	}

	@Override
	protected boolean _hasCollapsingToolbar()
	{
		// TODO: Implement this method
		return false;
	}

	@Override
	protected int _getSearchViewId()
	{
		// TODO: Implement this method
		return R.id.menu_search;
	}

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		//$addFragment(new WebFragment("https://www.blogger.com/feeds/7118757755628315212/posts/default/2962366599907150944?alt=json"),"Announcement");
		
		mainFrag=new MainFragment("https://devofandroid.blogspot.com/feeds/posts/default?alt=json&max-results=999");
		$addFragment(mainFrag,"Tutorials");
	}

	@Override
	protected void _searchTextChange(String searchText)
	{
		mainFrag.filter(searchText);
	}
	
	
}

package nnl.aide.material;

import android.os.*;
import android.support.v4.app.*;
import android.view.*;
import android.webkit.*;
import java.util.*;
import android.widget.*;

public class WebFragment extends Fragment
{
	WebView wv;
	String url;
	
	public WebFragment(String url){
		this.url=url;
	}
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		View view=inflater.inflate(R.layout.web_layout,null,false);
		wv=view.findViewById(R.id.wv);
		wv.getSettings().setJavaScriptEnabled(true);
		wv.setWebViewClient(new WebViewClient());
		
		new BaseGetTask<Post>(new BaseGetTask.TaskCompletionListener<Post>(){
				String html="";
				@Override
				public void onComplete(Post post)
				{
					if(post!=null){
						html="<h1>"+post.title+"</h1><br>"+
							post.published+"<br><br>"+post.content;

					}else{
						html="No status published.";
					}

					wv.loadDataWithBaseURL("file:///",html,"text/html","utf-8",null);
				}

				@Override
				public void onError(String msg)
				{
					Toast.makeText(getActivity(),msg,0).show();
				}
			}, new SinglePostParser()).execute(url);
		
//		new HttpGetTask2(new HttpGetTask2.TaskCompletionListener(){
//				String html="";
//				@Override
//				public void onComplete(List<Post> posts)
//				{
//					if(posts.size()>0){
//						Post post=posts.get(0);
//						Toast.makeText(getActivity(),"webfrag: "+post.content,1).show();
//						
//						html="<h1>"+post.title+"</h1><br>"+
//							post.published+"<br><br>"+post.content;
//						
//					}else{
//						html="No status published.";
//					}
//					
//					wv.post(new Runnable(){
//
//							@Override
//							public void run()
//							{
//								wv.loadDataWithBaseURL("file:///",html,"text/html","utf-8",null);
//							}
//						});
					
//				}
//
//				@Override
//				public void onError(final String msg)
//				{
//					wv.post(new Runnable(){
//
//							@Override
//							public void run()
//							{
//								wv.loadDataWithBaseURL("file:///",msg,"text/html","utf-8",null);
//							}
//						});
//					;
//				}
//			},true).execute(url);
		
		
		
		return view;
	}
	
	public boolean onBackPressed(){
		if(isVisible()){
			if(wv.canGoBack()){
				wv.goBack();
				return true;
			}
		}
		return false;
	}
}

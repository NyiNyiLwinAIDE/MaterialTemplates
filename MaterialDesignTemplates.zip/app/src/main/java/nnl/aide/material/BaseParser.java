package nnl.aide.material;

public abstract class BaseParser<T>
{
	public abstract T parse(String str);
}
